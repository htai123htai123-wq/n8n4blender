from .panels import register as register_panels, unregister as unregister_panels

def register():
    register_panels()

def unregister():
    unregister_panels()