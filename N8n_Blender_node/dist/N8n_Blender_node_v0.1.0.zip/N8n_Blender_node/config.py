"""
N8n Blender Node - 配置文件
定义插件的基本配置信息
"""

# 插件名称
__addon_name__ = "N8n_Blender_node"